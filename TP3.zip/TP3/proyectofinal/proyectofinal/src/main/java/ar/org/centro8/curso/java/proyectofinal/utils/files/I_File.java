package ar.org.centro8.curso.java.proyectofinal.utils.files;

// Interface para el manejo de Archivos

public class I_File {

    // Imprime el contenido del archivo en consola.
    
    
}
